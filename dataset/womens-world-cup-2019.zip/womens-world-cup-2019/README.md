---
files:
  - https://projects.fivethirtyeight.com/soccer-api/international/2019/wwc_matches.csv
  - https://projects.fivethirtyeight.com/soccer-api/international/2019/wwc_forecasts.csv
---
# Women's World Cup 2019

This file contains links to the data behind our [2019 Women's World Cup Predictions](https://projects.fivethirtyeight.com/2019-womens-world-cup-predictions/).

`wwc_matches.csv` contains match-by-match projections.

`wwc_forecasts.csv` contains our tournament forecasts.
